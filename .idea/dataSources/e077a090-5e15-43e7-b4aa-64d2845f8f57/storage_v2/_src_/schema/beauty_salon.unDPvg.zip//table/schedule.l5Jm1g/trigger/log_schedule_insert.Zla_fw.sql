create definer = root@localhost trigger log_schedule_insert
    after insert
    on schedule
    for each row
BEGIN 
	INSERT INTO 
		logs ( 
		salon_id, 
		artisan_id, 
		service_id, 
		user_id, 
		meeting, 
		status_id 
		) 
	VALUES ( 
		NEW.salon_id, 
		NEW.artisan_id, 
		NEW.service_id, 
		NEW.user_id, 
		NEW.meeting, 
		NEW.status_id 
	); 
END;

