create
    definer = root@`127.0.0.1` procedure clear_schedule()
BEGIN
	DELETE FROM
			schedule
		WHERE
			YEAR(meeting) < YEAR(NOW() - 1);
END;

